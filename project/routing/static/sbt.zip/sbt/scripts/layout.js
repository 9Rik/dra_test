define(["d3"], function (d3)
{
	function layout(moduleDef){
		
		return {};
	}
	return layout;
});